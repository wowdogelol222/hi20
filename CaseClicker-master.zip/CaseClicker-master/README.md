# CSGO-Case-Clicker
A website-based CSGO case clicker: https://kingofkfcjamal.github.io/CaseClicker

This is the source for the CSGO Clicker you know and love. Please expand on to it if you want. Would love to see what you guys can make for it.

